import random
import turtle
from turtle import Turtle, Screen

screen = Screen()
screen.setup(width=1000, height=500)

all_turtles = []

t_color = ["black", "blue", "red", "green", "brown", "grey"]

starting_positions = [(-480, -70), (-480, -40), (-480, -10), (-480, 20), (-480, 50), (-480, 80)]

for i in range(0, 6):
    new_turtle = Turtle("turtle")
    new_turtle.penup()
    new_turtle.color(t_color[i])
    all_turtles.append(new_turtle)
    new_turtle.goto(starting_positions[i])

bet = screen.textinput(title="Make a bet", prompt="What turtle color will win the race? ")

if bet:
    is_on = True

while is_on:
    for turtles in all_turtles:
        if turtles.xcor() > 480:
            is_on = False
            winner = turtles.pencolor()
            if winner == bet:
                print(f"You win! The {winner} turtle won the race")
            else:
                print(f"You lose! The {winner} turtle won the race")

        pace = random.randint(1, 10)
        turtles.forward(pace)
screen.exitonclick()






































































